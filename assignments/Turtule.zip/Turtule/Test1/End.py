﻿# Make all the "turtle" commands available to us.
import turtle

# End the turtle functionality
turtle.done()

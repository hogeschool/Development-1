﻿# Step 1: Make all the "turtle" commands available to us.
import turtle


# do not remove this
turtle.done()


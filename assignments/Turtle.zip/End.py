﻿# Close turtle
from turtle import done
done()
